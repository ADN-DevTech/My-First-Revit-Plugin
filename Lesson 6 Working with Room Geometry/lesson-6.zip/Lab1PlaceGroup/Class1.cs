﻿using Autodesk.Revit.DB;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Autodesk.Revit.DB.Architecture;

namespace Lab1PlaceGroup
{
    [Transaction(TransactionMode.Manual)]
    public class Class1 : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            //Get application and document objects 
            UIApplication uiapp = commandData.Application;
            Document doc = uiapp.ActiveUIDocument.Document;
            try
            {
                //Define a reference Object to accept the pick result 
                Reference pickedref;

                //Pick a group 
                Selection sel = uiapp.ActiveUIDocument.Selection;

                //pickedref = sel.PickObject(ObjectType.Element, "Please select a group");
                GroupPickFilter selFilter = new GroupPickFilter();
                pickedref = sel.PickObject(ObjectType.Element, selFilter, "Please select a group");

                Element elem = doc.GetElement(pickedref);
                Group? group = elem as Group;
                if (group == null)
                {
                    message = "Unable to obtain a group";
                    return Result.Failed;
                }

                // Get the group's center point 
                XYZ origin = GetElementCenter(group);
                // Get the room that the picked group is located in 
                Room? room = GetRoomOfGroup(doc, origin);
                if (room == null)
                {
                    message = "Could not find a room for the indicated group";
                    return Result.Failed;
                }
                // Get the room's center point  
                XYZ sourceCenter = GetRoomCenter(room);
                string coords =
                "X = " + sourceCenter.X.ToString() + "\r\n" +
                "Y = " + sourceCenter.Y.ToString() + "\r\n" +
                "Z = " + sourceCenter.Z.ToString();

                TaskDialog.Show("Source room Center", coords);

                //Pick point 
                //XYZ point = sel.PickPoint("Please pick a point to place group");

                //Place the group 
                Transaction trans = new Transaction(doc);
                trans.Start("Lab");
                //doc.Create.PlaceGroup(point, group?.GroupType);
                XYZ groupLocation = sourceCenter + new XYZ(20, 0, 0);
                doc.Create.PlaceGroup(groupLocation, group.GroupType);
                trans.Commit();
            }
            //If the user right-clicks or presses Esc, handle the exception 
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                return Result.Cancelled;
            }
            
            catch (Exception ex)
            {
                message = ex.Message;
                return Result.Failed;
            }
            return Result.Succeeded;
        }

        public XYZ GetElementCenter(Element elem)
        {
            BoundingBoxXYZ bounding = elem.get_BoundingBox(null);
            XYZ center = (bounding.Max + bounding.Min) * 0.5;
            return center;
        }

        /// Return the room in which the given point is located 
        Room? GetRoomOfGroup(Document doc, XYZ point)
        {
            FilteredElementCollector collector = new FilteredElementCollector(doc);
            collector.OfCategory(BuiltInCategory.OST_Rooms);
            Room? room = null;
            foreach (Element elem in collector)
            {
                room = elem as Room;
                if (room != null)
                {
                    // Decide if this point is in the picked room         
                    if (room.IsPointInRoom(point))
                    {
                        break;
                    }
                }
            }
            return room;
        }

        /// Return a room's center point coordinates. 
        /// Z value is equal to the bottom of the room 
        public XYZ GetRoomCenter(Room room)
        {
            // Get the room center point.             
            XYZ boundCenter = GetElementCenter(room);
            LocationPoint locPt = (LocationPoint)room.Location;
            XYZ roomCenter = new XYZ(boundCenter.X, boundCenter.Y, locPt.Point.Z);
            return roomCenter;
        }
    }
    
    public class GroupPickFilter : ISelectionFilter
    {
        public bool AllowElement(Element elem)
        {
            if (elem.Category?.Id?.Value == (int)BuiltInCategory.OST_IOSModelGroups)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool AllowReference(Reference reference, XYZ position)
        {
            return false;
        }
    }
}
